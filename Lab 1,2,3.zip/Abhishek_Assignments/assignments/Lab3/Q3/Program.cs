﻿using CarLib;
class program
{
    public static int Main(string[] args)
    {
      
        Console.WriteLine("enter number of cars you want to store-------------------- =");
        int num=Convert.ToInt32(Console.ReadLine());
        Car[] cars = new Car[num];
       

        /*foreach(Car car in cars)
        {
            Console.WriteLine("Details of cars -----------------");
            Console.WriteLine(car.Make);
            Console.WriteLine(car.Model);
            Console.WriteLine(car.Year);
            Console.WriteLine(car.SalePrice);
        }*/

        int i = 0;
        char status = 'y';
        do
        {
            char ch;
           
            Console.WriteLine("Enter 1 to add      2 to modify      3 to Search      4  to View all     5 to delete-    6 to quit--------------- ");
            ch = Convert.ToChar(Console.ReadLine());
            switch (ch)
            {
                case '1':
                    for(int k = 0; k < cars.Length; k++)
                    {
                        Car car = new Car();
                        car.AddCar();
                        cars[k] = car;
                        
                    }
                
                    break;
                case '2':

                    Car car2 = new Car();
                    int index;
                    Console.WriteLine("Enter the index number which you want to modify-----------------------");
                    index = Convert.ToInt32(Console.ReadKey());
                    Console.WriteLine("Details of car in that index are =");
                    Console.WriteLine("Make  Model  year  Saleprice ");
                    Console.WriteLine(cars[index].Make + "  " + cars[index].Model + "  " + cars[index].Year + "  " + cars[index].SalePrice);
                    Console.ReadLine();
                    Console.WriteLine("Enter new details Make , model , year and price respectively");
                    car2.AddCar();
                    //cars[index].Make = Console.ReadLine();
                    //cars[index].Model = Console.ReadLine();
                    //cars[index].Year = Convert.ToInt32(Console.ReadLine());
                    //cars[index].SalePrice = Convert.ToInt32(Console.ReadLine());

                    cars[index] = car2;
                    Console.WriteLine("Make  Model  year  Saleprice of modified car= ");
                    Console.WriteLine(cars[index].Make + "  " + cars[index].Model + "  " + cars[index].Year + "  " + cars[index].SalePrice);
                    Console.ReadLine();
                    break;

                case '3':
                    Console.WriteLine("enter the index number you want  to search=");
                    int index1 = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Make  Model  year  Saleprice of searched car= ");
                    Console.WriteLine(cars[index1].Make + "  " + cars[index1].Model + "  " + cars[index1].Year + "  " + cars[index1].SalePrice);
                    Console.ReadLine();
                    break;


                case '4':
                    Console.WriteLine("list of all cars =");
                    foreach (Car car1 in cars)
                    {
                        Console.WriteLine("Details of cars -----------------");
                        Console.WriteLine(car1.Make);
                        Console.WriteLine(car1.Model);
                        Console.WriteLine(car1.Year);
                        Console.WriteLine(car1.SalePrice);
                    }
                    Console.ReadLine();
                    break;

                case '5':
                    Console.WriteLine("enter the index no from which you want to delete");
                    int index2 = Convert.ToInt32(Console.ReadLine());

                   for(int j=index2;j<cars.Length;j++)
                    {
                       
                        if(j>=index2 && j<(cars.Length-1))
                        {
                            cars[j] = cars[j + 1];
                        }
                    }

                    cars[(cars.Length) - 1].Make = "0";
                    cars[(cars.Length) - 1].Model = "0";
                    cars[(cars.Length) - 1].Year = 0;
                    cars[(cars.Length) - 1].SalePrice =0;


                    Console.WriteLine("Newly formed list ");
                    foreach (Car car1 in cars)
                    {
                        Console.WriteLine("Details of cars -----------------");
                        Console.WriteLine(car1.Make);
                        Console.WriteLine(car1.Model);
                        Console.WriteLine(car1.Year);
                        Console.WriteLine(car1.SalePrice);
                    }
                    Console.ReadLine();
                    break;

                case '6':
                    break;

                default:
                    Console.WriteLine("Enter a valid key please!!!!!!!!!!!!!");
                    break;
            }

            Console.WriteLine("want to continue? Y/N");
            status=Convert.ToChar(Console.ReadLine());  


        } while(status == 'y');
        Console.ReadLine();
        return 0;

        
    } 
        
        
    
}