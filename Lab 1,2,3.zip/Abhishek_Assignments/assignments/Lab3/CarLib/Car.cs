﻿namespace CarLib
{
    public class Car
    {
        
            public string Make { get; set; }
            public string Model { get; set; }
            public int Year { get; set; }
            public int SalePrice { get; set; }

        public void AddCar()
        {
            Console.WriteLine("Enter details of cars 1:Make, 2:Model , 3:year 4:Salesprice");
            Make = Console.ReadLine();
            Model = Console.ReadLine();
            Year = Convert.ToInt32(Console.ReadLine());
            SalePrice = Convert.ToInt32(Console.ReadLine());
        }

        public static  void ModifyCar(string make,string model,int year,int salesprice)
        {
            
        }

        public void SearchCar()
        {

        }

        public void ShowCar()
        {

        }

        public void DeleteCar()
        {

        }


    }
}