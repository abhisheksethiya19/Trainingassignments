﻿namespace ParticipantLib
{
    public class Participants
    {

        /*Create a library project and define a class called Participant.Define the private members and public
        properties as follows:
        EmpId, Name, Company Name, FoundationMarks, WebBasicMarks, DotNetMarks, Total Marks,
        ObtainedMarks, Percentage
        Initialise the Total Marks to 300. ObtainedMarks and Percentage are calculated fields.*/

        private static string companyName;

        private int empId;
        private string name;
        private int foundationMarks;
        private int webbasicMarks;
        private int dotnetMarks;
        private int totalMarks;
        private int obtainedMarks;
        private int percentage;

        public static string CompanyName { get; set; }
        public int EmpId { get { return empId; } set { empId = value; } }
        public string Name { get { return name; } set { name = value; } }
        public int FoundationMarks
        { get
            {
                return foundationMarks; 
            } 
            set
            {
                if (value >= 0 && value <= 100)
                {
                    foundationMarks = value;
                }
                else
                {
                    foundationMarks = 0;
                }
            }
        }
        public int WebbasicMarks { get { return webbasicMarks; }
            set
            {
                if (value >= 0 && value <= 100)
                {
                    webbasicMarks = value;
                }
                else
                {
                    webbasicMarks = 0;
                }
            }
        }
        public int DotnetMarks { get { return dotnetMarks; }
            set
            {
                if (value >= 0 && value <= 100)
                {
                    dotnetMarks = value;
                }
                else
                {
                   dotnetMarks = 0;
                }
            }
        }
        public int TotalMarks { get { return totalMarks; } set { totalMarks = value; } }
        public int ObtainedMarks { get { return obtainedMarks; } set { empId = obtainedMarks; } }
        public int Percentage { get { return percentage; } set { percentage = value; } }


        public  Participants()
        {
            totalMarks = 300;
        }
        
         static Participants()
        {
            CompanyName = "Corporate University";
        }

        public Participants(int empId,string name,int foundationMarks,int webbasicMarks,int dotnetMarks)
        {
            this.empId = empId;
            this.name = name;
            this.foundationMarks= foundationMarks;
            this.webbasicMarks= webbasicMarks;
            this.dotnetMarks= dotnetMarks;
        }
        public void GetData()
        {
            EmpId = Convert.ToInt32(Console.ReadLine());
            Name = Console.ReadLine();
            FoundationMarks = Convert.ToInt32(Console.ReadLine());
            WebbasicMarks = Convert.ToInt32(Console.ReadLine());
            DotnetMarks = Convert.ToInt32(Console.ReadLine());
        }
       
        public void CalculateObtainedMarks()
        {
            obtainedMarks = (foundationMarks+ webbasicMarks+ dotnetMarks);
        }

        public void CalculatePercentage()
        {
            percentage=(obtainedMarks*100)/totalMarks;
        }

        public int GivePercentage()
        {
            return percentage;
        }
        public void ShowData()
        {
            
            Console.Write(EmpId +",");
            Console.Write(Name + ",");
            Console.Write(FoundationMarks + ",");
            Console.Write(WebbasicMarks + ",");
            Console.Write(DotnetMarks + ",");
            Console.Write(ObtainedMarks + ",");
            Console.WriteLine(Percentage + ",");
        }

    }
}