﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4
{
    internal class Supplier
    {
        //id,name,city,phone,email
        public int supplierId { get; set; } 
        public string supplierName { get; set; }
        public string supplierCity { get; set; }    
        public string supplierPhone { get; set; }
        public string email { get; set; }

        public void AcceptDetails()
        {
            Console.WriteLine("Enter id, name,city,phone,email=");
            supplierId = Convert.ToInt32(Console.ReadLine());
            supplierName=Console.ReadLine();
            supplierCity = Console.ReadLine();
            supplierPhone=Console.ReadLine();   
            email= Console.ReadLine();

        }

        public void DisplayDetails()
        {
            Console.Write(supplierId);
            Console.Write(supplierName);
            Console.Write(supplierCity);
            Console.Write(supplierPhone);
            Console.Write(email);
        }
    }
}
