﻿using Q4;
class SupplierTest
{
    public static int Main(string[] args)
    {
        Supplier sup = new Supplier();
        sup.AcceptDetails();
        sup.DisplayDetails();
        Console.ReadKey();
        return 0;
    }
}