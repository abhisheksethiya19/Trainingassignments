﻿using ParticipantLib;
using System;
class Program
{
    public static int Main(string[] args)
    {
        Participants participant = new Participants();
        Console.WriteLine("Students data application------------------------------------------------");
        Console.WriteLine("enter student details 1: id, 2: name,3: foundation marks, 4:webbasicmarks, 5:dotnetmarks  ");
        participant.GetData();      
        participant.CalculateObtainedMarks();
        participant.CalculatePercentage();
        Console.WriteLine("press any key to view data=");
        Console.ReadLine();
        Console.WriteLine("Id , Name , Foundation marks , Webmarks  ,Dotnetmarks, Obtained marks, Percentage are :");
        participant.ShowData();
        Console.ReadLine();

        return 0;
    }
}
