﻿using System;
using CalculatorLib;
class Program
{
    static int Main(string[] args)
    {
        Console.WriteLine("------ Calculator Application ------");
        char choice;
        //
        do
        {
            Console.WriteLine("Press 1 for Addition, 2 for Subtraction, 3 for Multiplication, 4 for Division and 5 to Exit.");
            double operation = Convert.ToInt32(Console.ReadLine());
            double firstNo;
            double secondNo;
            Console.WriteLine("Enter FirstNo:");
            firstNo = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter SecondNo:");
            secondNo = Convert.ToDouble(Console.ReadLine());
            double result;
            
            ArithmeticOperations objArithmeticOperation = new ArithmeticOperations();
            switch (operation)
            {
                case 1:
                    //Addition
                    result = objArithmeticOperation.Addition(firstNo, secondNo);
                    Console.WriteLine("Addition of two numbers is: " + result);
                    break;
                case 2:
                    //Subtraction
                    result = objArithmeticOperation.Subtraction(firstNo, secondNo);
                    Console.WriteLine("Subtraction of two numbers is: " + result);
                    break;
                case 3:
                    //Multiplication
                    result = objArithmeticOperation.Multiplication(firstNo, secondNo);
                    Console.WriteLine("Multiplication of two numbers is: " + result);
                    break;
                case 4:
                    //Division
                    result = objArithmeticOperation.Division(firstNo, secondNo);
                    Console.WriteLine("Division of two numbers is: " + result);
                    break;
                case 5:
                    //Exit
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Please choose correct option.");
                    break;
            }
            Console.WriteLine("Do you want to continue?. Press 'y' to continue and 'n' to exit.");
            choice = Convert.ToChar(Console.ReadLine());

        } while (choice == 'y');
        //
        Console.ReadLine();
        return 0;
    }


}
