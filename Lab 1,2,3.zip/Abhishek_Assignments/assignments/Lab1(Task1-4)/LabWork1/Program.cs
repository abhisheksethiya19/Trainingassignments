﻿

using System;
using EmployeeLib;
class Program
{
    static int Main(string [] args)
    {
        Employee[] objEmployee = new Employee[10];
        for(int i = 0; i < objEmployee.Length; i++)
        {
            Console.WriteLine("Enter details for "+ (i+1) + "Employee");
            objEmployee[i] = new Employee();
            objEmployee[i].SetValue();
        }
        Console.WriteLine("Enter a key to see details=");

        Console.ReadLine();
        Console.Clear();
        for (int i = 0; i < objEmployee.Length; i++)
        {
            Console.WriteLine(" details for " + (i + 1) + "Employee");
            
            objEmployee[i].ShowValue();
        }
        Console.ReadLine();
                return 0;
    }


}