﻿using System;
using EmployeeLib;
namespace ClassLibraryBussinessLogic
{
    public static class EmployeeWork
    {
        Employee[] objEmployee = new Employee[10];
        for(int i = 0; i<objEmployee.Length; i++)
        {
            Console.WriteLine("Enter details for "+ (i+1) + "Employee");
            objEmployee[i] = new Employee();
        objEmployee[i].SetValue();
    }
    Console.WriteLine("Enter a key to see datails=");

        Console.ReadLine();
        Console.Clear();
        for (int i = 0; i<objEmployee.Length; i++)
        {
            Console.WriteLine(" details for " + (i + 1) + "Employee");
            
            objEmployee[i].ShowValue();
}
Console.ReadLine();
    }
}