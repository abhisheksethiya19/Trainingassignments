﻿namespace SwitchCase
{
    class Program
    {
        public static int Main(string[] args)
        {
            int number;
            Console.WriteLine("enter a number from 1 to 5");
            number = Convert.ToInt32(Console.ReadLine());
            switch(number)
            {
                case 1:
                    Console.WriteLine("you entered " + number);
                    Console.ReadLine();
                    break;

                case 2:
                    Console.WriteLine("you entered " + number);
                    Console.ReadLine();
                    break;

                case 3:
                    Console.WriteLine("you entered " + number);
                    Console.ReadLine();
                    break;

                case 4:
                    Console.WriteLine("you entered " + number);
                    Console.ReadLine();
                    break;

                case 5:
                    Console.WriteLine("you entered " + number);
                    Console.ReadLine();
                    break;
                default:
                    Console.WriteLine("Error! enter valid number");
                    Console.ReadLine();
                    break;
            }
            return 0;
        }
    }
}