﻿namespace SchoolLib
{
   
       public  class Student
        {
            private int rollno;
            private string studentname;
            private byte age;
            private DateTime dateofbirth;
            private char gender;
            private string address;
            private double percentage;


           public int Rollno
           { 
            get { return rollno; }
            set { rollno = value; } 
           }

         public string  Studentname
         {
            get { return studentname; }
            set { studentname = value; }
         }

        public byte Age
        {
            get { return age; }
            set { age = value; }
        }

        public char Gender
        {
            get { return gender; }
            set { gender = value; }
        }

        public string  Address
        {
            get { return address; }
            set { address = value; }
        }

        public double  Percentage
        {
            get { return percentage; }
            set { percentage = value; }
        }


    }
    
}
