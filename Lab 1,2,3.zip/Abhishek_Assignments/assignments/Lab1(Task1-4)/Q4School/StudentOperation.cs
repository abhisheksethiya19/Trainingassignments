﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SchoolLib;
namespace Q4School
{
    internal class StudentOperation
    {
       public Student GetData()
        {
            Student student = new Student();
            student.Rollno =Convert.ToInt32(Console.ReadLine());
            student.Studentname = Console.ReadLine();
            student.Age=Convert.ToByte(Console.ReadLine());
            student.Gender=Convert.ToChar(Console.ReadLine());
            student.Address = Console.ReadLine();
            student.Percentage = Convert.ToDouble(Console.ReadLine());



            return student;
        }

        public void PutData(Student objStudent)
        {
            Console.WriteLine("Details are :------------------------------------");
            Console.WriteLine(objStudent.Rollno);
            Console.WriteLine(objStudent.Studentname);
            Console.WriteLine(objStudent.Age);
            Console.WriteLine(objStudent.Gender);
            Console.WriteLine(objStudent.Address);
            Console.WriteLine(objStudent.Percentage);
        }

    }
}
