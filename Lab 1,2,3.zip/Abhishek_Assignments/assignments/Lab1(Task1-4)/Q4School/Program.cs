﻿using System;
using SchoolLib;
namespace Q4School
{
    class Program
    {
        public static int  Main(string[] args)
        {
            
            Student objStudent = new Student();
            StudentOperation objstudentOperation = new StudentOperation();
            Console.WriteLine("Enter the details : 1: Rollno ,2: Name , 3:Age, 4;Gender(M/F) ,5:Address , 6:Percentage \n");
           objStudent= objstudentOperation.GetData();
            Console.Clear();
            Console.WriteLine("Press enter to view data of student:");
            Console.ReadLine();
            objstudentOperation.PutData(objStudent);

            Console.ReadLine();
            return 0;
        }
    }
}
