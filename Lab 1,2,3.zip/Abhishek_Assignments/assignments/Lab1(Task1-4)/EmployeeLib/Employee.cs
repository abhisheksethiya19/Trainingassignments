﻿using System;
namespace EmployeeLib
{
    public class Employee
    {

        private int employeeId;
        private string employeeName;
        private string address;
        private string city;
        private string department;
        private double salary;


        public  int EmployeeId { get; set; }
        public  string EmployeeName { get; set; }
        public  string Address { get; set; }
        public  string City    { get; set; }
        public   string Department { get; set; }
        public   double Salary { get; set; }



        //functions---------------


        public void SetValue()
        {
            Console.WriteLine("enter id:  ");
            EmployeeId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter name:  ");
            EmployeeName =Console.ReadLine();
            Console.WriteLine("enter address:  ");
            Address = Console.ReadLine();
            Console.WriteLine("city:  ");
            City = Console.ReadLine();
            Console.WriteLine("enter department:  ");
            Department = Console.ReadLine();
            Console.WriteLine("enter salary:  ");
            Salary = Convert.ToInt32(Console.ReadLine());
            
            Console.ReadLine();
        }
        public void ShowValue()
        {
            
            Console.WriteLine("ID:  "   + EmployeeId);
            Console.WriteLine("Name: " +EmployeeName);
            Console.WriteLine("Address: "+Address);
            Console.WriteLine( "city: " +City);
            Console.WriteLine( "Department: "+Department);
            Console.WriteLine("Salary: " + Salary);
        }


    }

    
}