﻿using System;

class Program
{
    public static int Main(string[] args)
    {
        Number1 objNumber1 = new Number1();
        Console.WriteLine("Enter a number=");
        objNumber1.num = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Square=");
        Console.WriteLine(objNumber1.Square());
        Console.WriteLine("Cube=");
        Console.WriteLine(objNumber1.Cube());
        Console.ReadLine();

        return 0;

      
    }




    struct Number1
    {
        public int num;
        public int Square()
        {
            return num * num;
        }

        public int Cube()
        {
            return num * num * num;
        }

    }
}
