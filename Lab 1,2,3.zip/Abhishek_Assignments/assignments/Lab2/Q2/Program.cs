﻿class Program
{
    public static int Main(string[] args)
    {
        int[,] numArray = new int[5,6];
        Console.WriteLine("Enter 6 elements for 2D array=");
        for (int i = 0; i < numArray.GetLength(0); i++)
        {
            for (int j = 0; j < numArray.GetLength(1); j++)
            {
                numArray[i, j] = Convert.ToInt32(Console.ReadLine());
            }
        }
            Console.Clear();
            Console.WriteLine("elements you entered are =");
        for (int i = 0; i < numArray.GetLength(0); i++)
        {
            for (int j = 0; j < numArray.GetLength(1); j++)
            {
               Console.Write( numArray[i, j] + "," + " ");
            }
        }

        Console.ReadKey();


      
        return 0;
    }
}
