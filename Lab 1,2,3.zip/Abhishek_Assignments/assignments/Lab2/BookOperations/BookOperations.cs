﻿namespace BookOperations
{
    public class BookOperations
    {

    }
}