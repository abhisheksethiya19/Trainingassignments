﻿using System;

class BookDemo
{
    public static int Main(string[] args)
    {
        string[,] books = new string[2, 4];
        
        for(int i = 0; i < books.GetLength(0); i++)
        {
            Console.WriteLine("Enter details of book" + (i+1));
            Console.WriteLine("enter title, author, publisher, price");


            for (int j = 0; j < books.GetLength(1); j++)
            {
                books[i, j] = Console.ReadLine(); 
            }
        }

        for (int i = 0; i < books.GetLength(0); i++)
        {
            Console.WriteLine(" details of book" + i + 1);
            Console.WriteLine(" title, author, publisher, price");


            for (int j = 0; j < books.GetLength(1); j++)
            {
                Console.Write(books[i,j]+ ","+ " ");
            }
            Console.WriteLine();
        }
        Console.ReadLine();

        return 0;
    }
}
