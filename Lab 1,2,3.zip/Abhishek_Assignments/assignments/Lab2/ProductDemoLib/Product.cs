﻿namespace ProductDemoLib
{
    public class Product
    { 

        public object Id { get; set; }
        public object Name
        {
            get; set;
        }
        public object Price
        {
            get; set;
        }
        public object Quantity
        {
            get; set;
        }
        public object AmountPayable
        {
            get; set;
        }

    }
}