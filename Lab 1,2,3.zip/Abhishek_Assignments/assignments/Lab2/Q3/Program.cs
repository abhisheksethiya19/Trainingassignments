﻿class Program
{
    public static int Main(string[] args )
    { 
        int num;
        Console.WriteLine("Enter number of strings you want to enter=");
        num=Convert.ToInt32(Console.ReadLine());
       
        string[] cities = new string[num];
        Console.WriteLine("enter strings");
        for (int i = 0; i < cities.Length; i++)
        {
            cities[i] = Console.ReadLine();
        }
        Console.WriteLine("Enter a key to view your strings");
        Console.ReadLine();
      

        foreach(string city in cities)
        {
            Console.WriteLine(city+ "," + " ");
        }

        Console.ReadLine();


        return 0;
    }
}
