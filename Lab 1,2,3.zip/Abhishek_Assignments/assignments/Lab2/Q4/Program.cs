﻿using ProductDemoLib;
using Q4;
class Program
{
    public static int Main(string[] args)
    {
        Console.WriteLine("enter details of product  1:Id,  2: Name,  3: Price  4:Quantity -----------");
        Product objProduct = new Product();
        ProductDemo objproductDemo = new ProductDemo();
        objProduct= objproductDemo.GetData();
        Console.WriteLine("enter to see product details--------------------");
        Console.ReadLine();
        objproductDemo.ShowData(objProduct);
        Console.ReadLine();
        return 0;
    }
}
