﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductDemoLib;

namespace Q4
{
    internal class ProductDemo
    {
       public Product GetData()
        {
            Product product = new Product();
            product.Id = Convert.ToInt32(Console.ReadLine());
            product.Name = Console.ReadLine();
            product.Price= Convert.ToInt32(Console.ReadLine());
            product.Quantity = Convert.ToInt32(Console.ReadLine());
            product.AmountPayable = Convert.ToInt32(product.Price) * Convert.ToInt32(product.Quantity);
            return product;
           
        }

        public void ShowData(Product product)
        {
            Console.WriteLine(product.Id);
            Console.WriteLine(product.Name);
            Console.WriteLine(product.Price);
            Console.WriteLine(product.Quantity);
            Console.WriteLine(product.AmountPayable);
            Console.WriteLine();
        }

    }
}
