﻿using ClassLibrary1;

class Program
{
    public static int Main(string[] args)
    {

        ICICI objaccount1= new ICICI();

        objaccount1.AccountType = BankAccountTypeEnum.Saving;
        objaccount1.Deposit(50000);

        ICICI objaccount2 = new ICICI();
        objaccount2.AccountType = BankAccountTypeEnum.Current;
        objaccount2.Deposit(20000);
        Console.WriteLine(objaccount1.GetBalance());
        Console.WriteLine(objaccount2.GetBalance());
        Console.ReadLine();

        objaccount1.Transfer(objaccount2, 10000);
        Console.WriteLine(objaccount1.GetBalance());
        Console.WriteLine(objaccount2.GetBalance());
        Console.ReadLine();




        HSBC objaccount11 = new HSBC();

        objaccount11.AccountType = BankAccountTypeEnum.Saving;
        objaccount11.Deposit(50000);

        HSBC objaccount22 = new HSBC();
        objaccount22.AccountType = BankAccountTypeEnum.Current;
        objaccount22.Deposit(20000);
        Console.WriteLine(objaccount11.GetBalance());
        Console.WriteLine(objaccount22.GetBalance());
        Console.ReadLine();

        objaccount11.Transfer(objaccount22, 10000);
        Console.WriteLine(objaccount11.GetBalance());
        Console.WriteLine(objaccount22.GetBalance());
        Console.ReadLine();

        



        return 0;
    }
}