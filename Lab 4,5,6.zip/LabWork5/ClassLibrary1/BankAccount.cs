﻿namespace ClassLibrary1
{

    public interface IBankAccount
    {
       public double GetBalance();
         public void Deposit(double amount);
         public bool Withdraw(double amount);
        public bool Transfer(IBankAccount toAccount, double amount);
      public   BankAccountTypeEnum AccountType { get; set; }
     public double CalculateInterest(IBankAccount account);


    }
    public  abstract class BankAccount:IBankAccount
    {
      public   BankAccountTypeEnum AccountType { get; set; }        //enum

        protected double balance;


        public double GetBalance()
        {
            return balance;
        }
        public void Deposit(double amount)
        {
            balance = balance + amount;
        }
        public abstract bool Withdraw(double amount);
        public abstract bool Transfer(IBankAccount toAccount, double amount);
        public abstract double CalculateInterest(IBankAccount account);
       
    }

    public enum BankAccountTypeEnum
    {
        Current = 1,
        Saving = 2
    }



  public   class ICICI :BankAccount
    {

       public override bool Withdraw(double amount) // Override this method
        {
            bool result;
            if(amount>=0)
            {
                balance = (balance - amount);
                result = true;
            }
            else
            {
                result=false;
            }
            // If Balance – amount is >= 0 then only WithDraw is possible.
            // Write the code to achieve the same.
            return result;
        }






       public override bool Transfer(IBankAccount toAccount, double amount) 
        {
            // If Balance – Withdraw is >= 1000 then only transfer can take place.
            // Write the code to achieve the same.
            bool status;

            if(amount>=1000)
            {
                this.balance = (this.balance) - amount;
                toAccount.Deposit(amount);
                status = true;

            }

            else
            {
                status=false;
            }
            return status;

        }





        public  override double CalculateInterest(IBankAccount account)
        {
            double interest;
            interest = (7 / 100) * balance;
            return interest;
        }


    }
   public  class HSBC :BankAccount
    {

        public override bool Withdraw(double amount) // Override this method
        {
            bool result;
            if (amount >= 0)
            {
                balance = (balance - amount);
                result = true;
            }
            else
            {
                result = false;
            }
            // If Balance – amount is >= 0 then only WithDraw is possible.
            // Write the code to achieve the same.
            return result;
        }







        public override bool Transfer(IBankAccount toAccount, double amount)
        {
            // If Balance – Withdraw is >= 1000 then only transfer can take place.
            // Write the code to achieve the same.
            bool status;

            if (amount >= 1000)
            {
                this.balance = (this.balance) - amount;
                toAccount.Deposit(amount);
                status = true;

            }

            else
            {
                status = false;
            }
            return status;

        }


        public override double CalculateInterest(IBankAccount account)
        {
            double interest;
            interest = (7 / 100) * balance;
            return interest;
        }
    }
}