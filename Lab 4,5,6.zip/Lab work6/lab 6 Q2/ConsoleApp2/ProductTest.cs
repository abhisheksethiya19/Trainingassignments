﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class ProductTest
    {
        public static int Main(string[] args)
        {
            try
            {
            ProductMock product = new ProductMock();
            product.GetProductDetails();
            product.DisplayDetails( product);
            }

            catch (DataEntryException ex)
            {
                Console.WriteLine(ex.Message);
            }
           
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


            Console.ReadLine();
            return 0;
        }
    }
}
