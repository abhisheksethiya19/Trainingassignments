﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
   public  class DataEntryException:ApplicationException
    {
        public DataEntryException() : base()
        {
            //Console.WriteLine("User defined exception from default constructor.");
        }
        public DataEntryException(string str) : base(str)
        {
            //Console.WriteLine("User defined exception from parameterized constructor."); 
        }
    }
}
