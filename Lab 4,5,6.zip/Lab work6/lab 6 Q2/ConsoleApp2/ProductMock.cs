﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class ProductMock
    {
        private int productId;
        private string productName;
        private int price;

        public int ProductId { get { return productId; } set { productId = value; } }
        public string ProductName { get { return productName; } set { productName = value; } }   
        public int Price { get { return price; } set { price = value; } }   


        public void GetProductDetails()
        {
            try
            {

           
            Console.WriteLine("Enter id, name and price of product");
            ProductId = Convert.ToInt32( Console.ReadLine());
            ProductName = Console.ReadLine();
            Price = Convert.ToInt32( Console.ReadLine());
                if(ProductId<0)
                {
                    throw new DataEntryException("Product id must be greater than 0");
                }
                 if(ProductName==" ")
                {
                    throw new DataEntryException("Product name cannt be empty");
                }
                 if(Price<=0)
                {
                    throw new DataEntryException("Price must be greater than 0");
                }
            }

            catch(DataEntryException )
            {
                throw;
            }
            catch(Exception)
            {
                throw;
            }
        }

        public void DisplayDetails(ProductMock product)
        {
            Console.WriteLine(product.ProductName);
            Console.WriteLine(product.Price);

        }
    }
}

/*      condition Exception Message
        productID <=0 Product ID must be greater than zero
        productName = = “” Product Name cannot be left blank
        price <=0 Price of product must be greater than zero.
        productName

*/