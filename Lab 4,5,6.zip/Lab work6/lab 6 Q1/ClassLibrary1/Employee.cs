﻿namespace ClassLibrary1
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string Department { get; set; }
        public int Salary { get; set; }

    }
}



/*  EmployeeId, Employee Name, Address, City, Department, Salary 
Define the functions to set the values of each property and to get the value of the Salary in the class: Compile 
the class to generate a DLL.    */