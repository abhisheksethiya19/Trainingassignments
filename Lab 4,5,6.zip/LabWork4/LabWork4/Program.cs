﻿using ContractEmpLib;
using PermanentEmpLib;
class Program
{
    public static int Main(string[] args)
    {
        int num;
        Console.WriteLine("press 1 for contract employee and 2 for permanent employee");
        num=Convert.ToInt32(Console.ReadLine());    
        switch(num)
        {
            case 1:
                ContractEmployee obj = new ContractEmployee();
                Console.WriteLine("Enter the details of the employee 1 id  2 name   3 address  4 city  5 department  6 salary 7 Perks");
                obj.SetValue();
                obj.GetSalary();
                Console.WriteLine("Final Salary of this employee is =");
                Console.WriteLine(obj.Salary);
                Console.ReadLine();
                break;

                case 2:
                PermanentEmployee obj1 = new PermanentEmployee();

                Console.WriteLine("Enter the details of the employee 1 id  2 name   3 address  4 city  5 department  6 salary  7 Provident fund");
                obj1.SetValue();
                obj1.GetSalary();
                Console.WriteLine("Final Salary of this employee is =");
                Console.WriteLine(obj1.Salary);
                Console.ReadLine();              
                break;

            default:
                Console.WriteLine("you entered wrong key , prss correct key only");
                break;
        }
        return 0;
    }
}