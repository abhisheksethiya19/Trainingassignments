﻿
using EmployeeLib;

namespace PermanentEmpLib
{
    public class PermanentEmployee:Employee
    {
        public int NoOfLeaves { get; set; }
        public double ProvidentFund { get; set; }

        public void GetSalary()
        {
            Salary = (Salary - ProvidentFund);
        }


        public override void SetValue()
        {
            Console.WriteLine("enter id:  ");
            EmployeeId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter name:  ");
            EmployeeName = Console.ReadLine();
            Console.WriteLine("enter address:  ");
            Address = Console.ReadLine();
            Console.WriteLine("city:  ");
            City = Console.ReadLine();
            Console.WriteLine("enter department:  ");
            Department = Console.ReadLine();
            Console.WriteLine("enter salary:  ");
            Salary = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter Provident fund:  ");
            ProvidentFund = Convert.ToInt32(Console.ReadLine());

            Console.ReadLine();
        }


        public override void ShowValue()
        {

            Console.WriteLine("ID:  " + EmployeeId);
            Console.WriteLine("Name: " + EmployeeName);
            Console.WriteLine("Address: " + Address);
            Console.WriteLine("city: " + City);
            Console.WriteLine("Department: " + Department);
            Console.WriteLine("Salary: " + Salary);
        }
    }
}